# CmpE 436 HW1

## To run the code: 
* Traverse to the exact *.java file location.
* javac Main.java
* java Main

### To run the code specifically for Q1:
* cd TestAndSet
* cd src
* javac Main.java
* java Main

### To run the code specifically for Q2:
* cd SwapMutex
* cd src
* javac Main.java
* java Main

### Reference:
For Testing, this code was edited and used.
https://www.tutorialspoint.com/java/java_multithreading.htm
